INSERT INTO product (name, price, description) VALUES 
('Notebook', 3500.0, 'Notebook 16G RAM, SSD 512GB'),
('Smartphone', 1500.0, 'Tela 6.5, 128GB'),
('Smartwatch', 500.0, 'Tela 2.5, 30GB'),
('Monitor', 400.0, 'Monitor 24" Full HD 144Hz'),
('Teclado', 900.0, 'Teclado mecanico RGB');