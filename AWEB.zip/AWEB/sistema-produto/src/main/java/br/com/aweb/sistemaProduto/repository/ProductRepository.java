package br.com.aweb.sistemaProduto.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.aweb.sistemaProduto.model.Product;

public interface ProductRepository extends JpaRepository<Product, Long>{
    
}
