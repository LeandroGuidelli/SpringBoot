package br.com.aweb.crud_db;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudDbApplicationTests {

	@Test
	void contextLoads() {
	}

}
