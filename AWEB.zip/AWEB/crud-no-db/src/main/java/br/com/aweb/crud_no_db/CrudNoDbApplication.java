package br.com.aweb.crud_no_db;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudNoDbApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudNoDbApplication.class, args);
	}

}
